<?php $__env->startSection('title', 'Achievers'); ?>
<?php $__env->startPush('achievers_active'); ?>
    active
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
  <!-- hero section start -->
  <section class="hero-section">
    <div class="hero-section-translucent d-flex flex-column align-items-center justify-content-center">
        <div class="img text-center">
            <img src="<?php echo e(asset('theme_1/images/0b340f_a659856b4c5c4a6da9c8a9e1620a8ae4~mv2_d_2189_2189_s_2.webp')); ?>" alt="" class="img-fluid">
        </div>
        <div class="text text-center">
            <h1>श्री कन्याकुब्ज ब्राह्मण समिति जोधपुर</h1>
        </div>
    </div>
</section>
  <!-- hero section end -->
  
  <!-- achievers section start -->
  <section class="team-boxed">
    <div class="container">
      <div class="text-center py-4" data-aos="zoom-in">
        <h4 class="heading playfair-display-heading">एचीवर्स</h4>
        <p class="lead">हर यात्रा की एक कहानी होती है और हर कहानी में एक सबक छिपा होता है।</br>
          जानिए कि कैसे हमारा रास्ता जुनून, दृढ़ता और उत्कृष्टता की निरंतर खोज से आकार लेता है।</p>
      </div>
  
      <!-- Time Period Filter -->
      <div class="mb-4 d-flex justify-content-end" data-aos="fade-right">
        <form id="yearFilterForm" action="/achievers" method="GET">
            <select id="timePeriodFilter" name="year" class="form-select form-select-sm w-auto" aria-label="Filter by Year" onchange="document.getElementById('yearFilterForm').submit();">
                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($year->year); ?>" <?php echo e($selectedYear == $year->year ? 'selected' : ''); ?>>
                        <?php echo e($year->year); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </form>
      </div>
  
      <div class="row people">
        <?php $__currentLoopData = $achievers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achiever): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 col-lg-3 item" data-aos="fade-up" data-year="<?php echo e($achiever->year); ?>">
            <div class="box border border-1 d-flex flex-column justify-content-between">
              <img class="img-fluid" src="<?php echo e(asset('storage/' . $achiever->image)); ?>" alt="<?php echo e($achiever->name); ?>">
              <div class="text-center">
                <h3 class="name mb-2"><?php echo e($achiever->name); ?></h3>
                <p class="title mb-3"><?php echo e($achiever->year); ?></p>
                <p><?php echo e($achiever->description); ?></p>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>
  <!-- achievers section end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/pacificsoftwares/Sites/kanyakubj-jodhpur/themes/theme_1/views/achievers.blade.php ENDPATH**/ ?>