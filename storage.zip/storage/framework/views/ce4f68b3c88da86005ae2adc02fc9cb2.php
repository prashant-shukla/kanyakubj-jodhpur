<div class="min-h-screen flex items-center justify-center bg-orange-600 p-8">
    <style>
        .fi-fo-wizard-header-step-label {
            font-size: 16px;
        }
        .fi-fo-wizard-header-step-description {
            font-size: 12px;
        }
    
        .fi-fo-wizard-header-step-indicator {
            font-size: 32px;
        }
    
        .fi-fo-wizard-header-step-icon-ctn {
            width: 50px;
            height: 50px;
        }
    </style>
    
    
    <div class="w-full max-w-7xl text-gray-800 p-8 rounded-lg shadow-lg mx-auto my-4">
        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="bg-green-500 text-white p-4 rounded-md mb-4">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <form wire:submit.prevent="submit">
            <div class="text-center">
                <hr /><br />
                <h1 class="text-6xl font-extrabold text-white bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 bg-clip-text text-transparent py-4 tracking-wide uppercase shadow-lg">
                    कान्यकुब्ज ब्राह्मण समाज, जोधपुर 
                </h1>
                <hr />

                <h2 class="text-2xl font-semibold text-gray-100 bg-gradient-to-r from-green-300 via-blue-400 to-purple-500 bg-clip-text text-transparent mt-4 tracking-wide">
                    सदस्यता आवेदन पत्र 
                </h2>
                <br />
            </div>

            <div class="dark bg-gray-800 rounded-lg">
                <?php echo e($this->form); ?>


                <br />
            
                <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['type' => 'submit','class' => 'w-full bg-gradient-to-r from-success-500 to-success-600 text-white hover:from-success-600 hover:to-success-700 font-semibold py-3 px-5 rounded-lg shadow-md transform transition-transform duration-300 ease-in-out hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-success-400 focus:ring-opacity-50 flex items-center justify-center space-x-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'w-full bg-gradient-to-r from-success-500 to-success-600 text-white hover:from-success-600 hover:to-success-700 font-semibold py-3 px-5 rounded-lg shadow-md transform transition-transform duration-300 ease-in-out hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-success-400 focus:ring-opacity-50 flex items-center justify-center space-x-2']); ?>
                    <span>सबमिट / SUBMIT</span>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
            </div>
        </form>

        <?php if (isset($component)) { $__componentOriginal028e05680f6c5b1e293abd7fbe5f9758 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-actions::components.modals','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-actions::modals'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758)): ?>
<?php $attributes = $__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758; ?>
<?php unset($__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal028e05680f6c5b1e293abd7fbe5f9758)): ?>
<?php $component = $__componentOriginal028e05680f6c5b1e293abd7fbe5f9758; ?>
<?php unset($__componentOriginal028e05680f6c5b1e293abd7fbe5f9758); ?>
<?php endif; ?>
    </div>
</div>


<?php /**PATH /Users/pacificsoftwares/Sites/kanyakubj-jodhpur/resources/views/livewire/member-form.blade.php ENDPATH**/ ?>