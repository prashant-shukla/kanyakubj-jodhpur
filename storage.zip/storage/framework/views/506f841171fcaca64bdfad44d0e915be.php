<?php $__env->startSection('title', 'Members'); ?>
<?php $__env->startPush('members_active'); ?>
    active
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
    <!-- hero section start -->
    <section class="hero-section">
        <div class="hero-section-translucent d-flex flex-column align-items-center justify-content-center">
            <div class="img text-center">
                <img src="<?php echo e(asset('theme_1/images/0b340f_a659856b4c5c4a6da9c8a9e1620a8ae4~mv2_d_2189_2189_s_2.webp')); ?>" alt="" class="img-fluid">
            </div>
            <div class="text text-center">
                <h1>श्री कन्याकुब्ज ब्राह्मण समिति जोधपुर</h1>
            </div>
        </div>
    </section>
    <!-- hero section end -->
    <!-- members section start -->
    <section class="team-boxed">
        <div class="container">
            <div class="text-center py-4" data-aos="fade-up">
                <h4 class="heading playfair-display-heading">समिति सदस्यगण</h4>
                <p class="lead">हर यात्रा की एक कहानी होती है और हर कहानी में एक सबक छिपा होता है।<br />जानिए कि कैसे हमारा रास्ता जुनून, दृढ़ता और उत्कृष्टता की निरंतर खोज से आकार लेता है।</p>
            </div>

            <!-- Time Period Filter -->
            <div class="mb-4 d-flex justify-content-end" data-aos="fade-right">
                <form id="timePeriodForm" action="/members" method="GET">
                    <select id="timePeriodFilter" name="tenure" class="form-select form-select-sm w-auto"
                        aria-label="Filter by Time Period" onchange="document.getElementById('timePeriodForm').submit();">
                        <?php
                            // Determine the selected tenure from the GET request, default to the first tenure if not set
                            $selectedTenure = $_GET['tenure'] ?? $tenures->first()->title;
                        ?>

                        <?php $__currentLoopData = $tenures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenureOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tenureOption->title); ?>"
                                <?php echo e($tenureOption->title == $selectedTenure ? 'selected' : ''); ?>>
                                <?php echo e($tenureOption->title); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
            </div>


            <div class="row people">
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-3 item" data-aos="zoom-in">
                        <div class="box border border-1 d-flex flex-column justify-content-between">
                            <img class="img-fluid" src="<?php echo e(asset('storage/' . $member->image)); ?>" alt="Ben Johnson">
                            <div class="text-center">
                                <h3 class="name mb-2"><?php echo e($member->name); ?></h3>
                                <p class="title mb-3"><?php echo e($member->position); ?></p>
                                <p class="title mb-3"><?php echo e($tenure); ?></p>
                                <div class="social">
                                    <?php
                                        $socialLinks = json_decode($member->social_media_links, true);
                                    ?>

                                    <?php if(!empty($socialLinks['facebook'])): ?>
                                        <a href="<?php echo e($socialLinks['facebook']); ?>"><i class="fa-brands fa-facebook"></i></a>
                                    <?php endif; ?>
                                    <?php if(!empty($socialLinks['x'])): ?>
                                        <a href="<?php echo e($socialLinks['x']); ?>"><i class="fa-brands fa-x"></i></a>
                                    <?php endif; ?>
                                    <?php if(!empty($socialLinks['instagram'])): ?>
                                        <a href="<?php echo e($socialLinks['instagram']); ?>"><i class="fa-brands fa-instagram"></i></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/pacificsoftwares/Sites/kanyakubj-jodhpur/themes/theme_1/views/members.blade.php ENDPATH**/ ?>