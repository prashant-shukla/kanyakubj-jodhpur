<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', env('APP_NAME')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Include livewire CSS -->
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <!-- Include Filament CSS -->
    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>

    <link
        href="<?php echo e(env('APP_URL')); ?>/css/filament/filament/app.css"
        rel="stylesheet"
        data-navigate-track
    />


</head>
<body style="background: #FF671F;" >
    <div class="">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>

</body>
</html>
<?php /**PATH /Users/pacificsoftwares/Sites/kanyakubj-jodhpur/resources/views/layouts/app.blade.php ENDPATH**/ ?>